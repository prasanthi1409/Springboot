package com.jsp.springbootdemo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.entities.Product;
import com.jsp.spingbootdemo.helper.ResponseStructure;
import com.jsp.sprintbootdemo.respository.ProductRepository;
@RestController
public class ProductController {
	@Autowired
	ProductRepository pr;

	
	
	@PostMapping("/saveproduct")
	public ResponseStructure saveProduct(@RequestBody Product product)
	{
		pr.save(product);
		ResponseStructure<Product> pr=new ResponseStructure<Product>();
		pr.setData(product);
		pr.setStatuscode(HttpStatus.CREATED.value());
	    pr.setMessage("product data save successfully");

		return pr;
		
	}

}
