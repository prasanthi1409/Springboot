package com.jsp.springbootdemo.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.jsp.spingbootdemo.helper.ResponseStructure;

@RestControllerAdvice//it is used to catch the exceptions and return http response
public class ExceptionManager {
	@ExceptionHandler(value=UserNotFoundException.class)
	public ResponseStructure<String> userNotFound(UserNotFoundException u)
	{
		ResponseStructure<String> rs= new ResponseStructure<String>();
		rs.setStatuscode(HttpStatus.NOT_FOUND.value());
		rs.setData(u.getMessage());
		rs.setMessage("request failed");
		return rs;
			
		}
	}


