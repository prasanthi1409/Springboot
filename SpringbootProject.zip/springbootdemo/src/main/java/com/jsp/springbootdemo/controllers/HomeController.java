package com.jsp.springbootdemo.controllers;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController //RestController=Controller+ResponseBody//responsebody=javaobject-json object
public class HomeController {
	@PostMapping("/hi")
	public String m1()
	{
		return "hello world-first program in springboot";
	}

}
