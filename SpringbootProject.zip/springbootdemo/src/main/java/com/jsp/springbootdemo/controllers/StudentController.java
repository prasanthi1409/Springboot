package com.jsp.springbootdemo.controllers;


import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.entities.Student;
import com.jsp.spingbootdemo.helper.ResponseStructure;
import com.jsp.sprintbootdemo.respository.StudentRepository;
@RestController//controller and ResponseBody//javaobject->json
public class StudentController {
	@Autowired
	StudentRepository sr;
	@PostMapping("/save")
	public ResponseStructure saveStudent(@RequestBody Student student)
	{
		sr.save(student);
		ResponseStructure<Student> rs=new ResponseStructure<Student>();
		rs.setStatuscode(HttpStatus.CREATED.value());
		rs.setData(student);
		rs.setMessage("data saved successfuly");
		 return rs;
	}
	@GetMapping("/fetchDataById")
	public ResponseStructure<Student> fetchDataById(@RequestParam("id") int id)
	{
		try {
		Optional<Student> option=sr.findById(id);
		Student s=option.get();
		ResponseStructure<Student> rs=new ResponseStructure<Student>();
		rs.setStatuscode(HttpStatus.FOUND.value());
		rs.setData(s);
		rs.setMessage("data found");
		
		return rs;
		}
		catch(NoSuchElementException ns)
		{
			ResponseStructure<Student> rs=new ResponseStructure<Student>();
			rs.setStatuscode(HttpStatus.NOT_FOUND.value());
			rs.setData(null);
			rs.setMessage("data not found");
			
			return rs;

		}
		
	}
	@GetMapping("/fetchdatabyname")
	public ResponseStructure<List<Student>> fetchDataByStudent(@RequestParam("name") String name)
	{
		
			List<Student> students=sr.findByName(name);
			if(students.size()>0)
			{
			ResponseStructure<List<Student>> rs=new ResponseStructure<List<Student>>();
			rs.setStatuscode(HttpStatus.FOUND.value());
			rs.setData(students);
			rs.setMessage("Data found");
			return rs;
			}
			else
			{
				ResponseStructure<List<Student>> rs=new ResponseStructure<List<Student>>();
				rs.setStatuscode(HttpStatus.NOT_FOUND.value());
				rs.setData(students);
				rs.setMessage("data not found");
				return rs;
			}
	}
			
		
	@PutMapping("/updatedata")
	public ResponseStructure<Student> updateStudent(@RequestBody Student student)
	{
		sr.save(student);
		try {
		ResponseStructure <Student> rs=new ResponseStructure <Student>();

		rs.setStatuscode(HttpStatus.ACCEPTED.value());
		rs.setData(student);
		rs.setMessage("data updated");
		return rs;
		
		
	} catch(Exception e) {
		ResponseStructure <Student> rs=new ResponseStructure <Student>();

		rs.setStatuscode(HttpStatus.NOT_ACCEPTABLE.value());
		rs.setData(null);
		rs.setMessage("data not updated");
		return rs;
	}
	}
	
	
	@DeleteMapping("/deletedata")
	
	public ResponseStructure<Student> deleteStudent(@RequestParam("id") int id)
	{
		Optional<Student> optional =sr.findById(id);
		Student s=optional.get();
		sr.deleteById(id);
		
		ResponseStructure <Student> rs=new ResponseStructure <Student>();
		rs.setStatuscode(HttpStatus.OK.value());
		rs.setData(s);
		rs.setMessage("data deleted");
		
		return rs;
		
	}
	
	
	@GetMapping("/fetchdatabetween")
	
	public ResponseStructure<List<Student>> fetchByAgeBetween(@RequestParam("start") int start,@RequestParam("end") int end)
	{
		List<Student> students=sr.findByAgeBetween(start, end);
		ResponseStructure<List<Student>> rs=new ResponseStructure<List<Student>>();
		rs.setStatuscode(HttpStatus.CREATED.value());
		rs.setData(students);
		rs.setMessage("data found");
		return rs;
	}
	
	@GetMapping("/AgeGreaterThan")
	
	public ResponseStructure<List<Student>> fetchByAgeGreaterThan(@RequestParam("age") int age)
	{
		List<Student> students=sr.findByAgeGreaterThan(age);
		ResponseStructure<List<Student>> rs=new ResponseStructure<List<Student>>();
		rs.setStatuscode(HttpStatus.CREATED.value());
		rs.setMessage("data found");
		rs.setData(students);
		return rs;
	}
	
	
	

}
