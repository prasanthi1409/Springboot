package com.jsp.springbootdemo.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.entities.Student;
import com.jsp.entities.User;
import com.jsp.spingbootdemo.helper.Login;
import com.jsp.spingbootdemo.helper.ResponseStructure;
import com.jsp.springbootdemo.exceptions.UserNotFoundException;
import com.jsp.sprintbootdemo.respository.UserRepository;
@RestController
public class UserController {
	@Autowired
	
	UserRepository ur;
	
	@PostMapping("/saveuser")
	
	public ResponseStructure saveuser(@RequestBody User user)
	{
		ur.save(user);
		
		ResponseStructure<User> rs=new ResponseStructure<User>();
		rs.setStatuscode(HttpStatus.CREATED.value());
		rs.setData(user);
		rs.setMessage("data saved");
		return rs;
	}
	
	@GetMapping("/validate")
	public ResponseStructure<User> loginValidation(@RequestBody Login login)
	{
		User u=ur.findByEmailAndPassword(login.getEmail(), login.getPassword());
		if(u!=null)
		{
			ResponseStructure<User> rs=new ResponseStructure<User>();
			rs.setStatuscode(HttpStatus.FOUND.value());
			rs.setData(u);
			rs.setMessage("user found");
			return rs;

		}
		else {
			ResponseStructure<User> rs=new ResponseStructure<User>();
			rs.setStatuscode(HttpStatus.NOT_FOUND.value());
			rs.setData(u);
			rs.setMessage("user not  found");
			return rs;



		}
		
	}
	
	
	@GetMapping("/fetchuserById")
	
	public ResponseStructure<User> fetchuser(@RequestParam("id") int id)
	{
		
		Optional<User> optional=ur.findById(id);
		if(optional.isPresent()) {
		ResponseStructure<User> rs=new ResponseStructure<User>();
		rs.setStatuscode(HttpStatus.FOUND.value());
		rs.setData(optional.get());
		rs.setMessage("data fetched");
		
		return rs;
		}
		else {
			throw new UserNotFoundException("data not found");
		}
		
		}
		
		
	@PutMapping("/updateuser")
	
	public ResponseStructure updateuser(@RequestBody User user)
	{
		ur.save(user);
		ResponseStructure<User> rs=new ResponseStructure<User>();
		rs.setStatuscode(HttpStatus.ACCEPTED.value());
		rs.setData(user);
		rs.setMessage("data updated");
		return rs;
	}
	@DeleteMapping("/deleteuser")
	public ResponseStructure deleteuser(@RequestParam("id") int id)
	{
		Optional<User> optional =ur.findById(id);
		User u=optional.get();
		ur.deleteById(id);
		
		ResponseStructure <User> rs=new ResponseStructure <User>();
		rs.setStatuscode(HttpStatus.OK.value());
		rs.setData(u);
		rs.setMessage("data deleted");
		
		return rs;
		
	}
	
	
		
	
	
	

}
